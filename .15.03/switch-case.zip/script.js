var select = document.querySelector('select');
var paragrafo = document.querySelector('p');

select.addEventListener('change', idadeAtleta);

function idadeAtleta() {

    const classificacao = select.value;

    switch (classificacao) {
        case 'infantilA':
            paragrafo.textContent = "classificação do atleta infantil A";
            break;

        case 'infantilB':
            paragrafo.textContent = "classificação do atleta infantil B";
            break;   

        case 'juvenilA':
            paragrafo.textContent = "classificação do atleta juvenil A";
            break;
        case 'juvenilB':
            paragrafo.textContent = "classificação do atleta juvenil B";
            break;
    }

}