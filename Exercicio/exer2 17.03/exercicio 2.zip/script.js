var texto = "";

for (var contador = 0; contador <= 10; contador++) {
    // texto += 'numero ' + contador + "<br>";
    texto += contador + "<br>";

}
document.getElementById("estruturaRepeticao").innerHTML = texto;