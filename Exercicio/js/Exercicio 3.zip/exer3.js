const numero = 4;

const numeroPar = (numero % 2) === 0;

if (numeroPar) {
    console.log('Par');
} else {
    console.log('Impar');
}

//---------------------------------------

var num = 10;

if (num > 10) {
    
    console.log("Esse número é maior que 10");
}
else if (num < 10) {
    console.log("Esse número é menor que 10");
}
else if (num === 10) {
    console.log("Esse numero é igual a 10");
}


